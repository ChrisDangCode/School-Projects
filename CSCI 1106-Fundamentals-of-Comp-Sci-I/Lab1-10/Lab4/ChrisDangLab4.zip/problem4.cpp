#include <iostream>
#include <iomanip>
using namespace std;


//testing data for problem 2
/*
int main () {

	int var1;
	char ch;
	string str;

	cout << "Type in an integer: " ;
	cin >> var1;
	getline (cin,str);

	cout << "Integer is: " << var1 <<'\n' ;
	cout << " String is: " << str <<'\n';

	return 0;


}
*/
//end main

//Problem 4


const double PAY_INCREASE = 0.076; //Workers get 7.6% increase

int main() {

	double oldYearPay, newYearPay, newMonthPay, retroPay;

	cout << "Please enter your annual salary: ";
	cin >> oldYearPay;

	retroPay = oldYearPay * PAY_INCREASE;
	newYearPay = retroPay + oldYearPay;
	newMonthPay = newYearPay / 12;

	cout << setprecision(2) << fixed; //sets to 2 decimal points and fixes e notation for answers
	cout << "The amount in retroactive pay you earned is: $" << setw(9) << retroPay << '\n';
	cout << "                  Your new annual salary is: $" << setw(9) << newYearPay << '\n';
	cout << "                  Your new montly salary is: $" << setw(9) << newMonthPay << '\n';

	return 0;

}